#!/bin/bash
set -euo pipefail
cd /home/ubuntu/ethics-t3
mkdir -p /home/ubuntu/ethics-t3/PROJECT/codebase/results/textbook_tool_full_20261110/phi4
test -x /home/ubuntu/ethics-venv/bin/python
test -d /home/ubuntu/ethics-ec2/model-cache/models--unsloth--Phi-4-mini-instruct-bnb-4bit
sudo install -m 644 deployment/ethics-t3-full.service deployment/ethics-t3-deadline.service deployment/ethics-t3-deadline.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl reset-failed ethics-t3-full.service 2>/dev/null || true
sudo shutdown -c 2>/dev/null || true
sudo systemctl start ethics-t3-deadline.timer
sudo systemctl start ethics-t3-full.service
echo T3_EC2_STARTED
